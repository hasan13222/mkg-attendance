export const studentsReports = [
  {
    present: 10,
    absent: 3,
    name: "Md. Jamil Hasan",
    roll: 10,
  },
  {
    present: 10,
    absent: 3,
    name: "Md. Jamil Hasan",
    roll: 10,
  },
  {
    present: 10,
    absent: 3,
    name: "Md. Jamil Hasan",
    roll: 10,
  },
  {
    present: 10,
    absent: 3,
    name: "Md. Jamil Hasan",
    roll: 10,
  },
];
