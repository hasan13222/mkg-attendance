export const studentsData = [
    {
        name : "John Doe",
        email : "johndoe@gmail.com",
        roll : 10,
    },
    {
        name : "John Doe",
        email : "johndoe@gmail.com",
        roll : 10,
    },
    {
        name : "John Doe",
        email : "johndoe@gmail.com",
        roll : 10,
    },
    {
        name : "John Doe",
        email : "johndoe@gmail.com",
        roll : 10,
    },
]