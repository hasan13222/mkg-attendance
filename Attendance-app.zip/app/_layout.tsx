import { useState } from "react";
import Login from "../components/login";
import Routes from "@/Navigations/Routes";
import { Provider } from "react-redux";
import store from "./../redux/store/index";
import {
  createStackNavigator,
  CardStyleInterpolators,
} from "@react-navigation/stack";
import DrawerNavigation from "./DrawerNavigation";
import Reports from "./Reports";
import Students from "./Students";
import { useTheme } from "@react-navigation/native";
import { StatusBar } from "react-native";

const RootLayout = () => {
  const [user, setUser] = useState(true);

  const Stack = createStackNavigator();

  const theme = useTheme();
  return user ? (
    <Provider store={store}>
      <StatusBar backgroundColor={theme.colors.card} barStyle={"dark-content"} /> 
      <Stack.Navigator
        initialRouteName={"FooterLayout"}
        detachInactiveScreens={true}
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: "transparent" },
          cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
        }}
      >
        <Stack.Screen
          name="DrawerNavigation"
          component={DrawerNavigation}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Reports"
          component={Reports}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Students"
          component={Students}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </Provider>
  ) : (
    <Login setUser={setUser} />
  );
};

export default RootLayout;
