import { createSlice } from "@reduxjs/toolkit";

const searchOptions = {
  date: new Date(),
  date2: new Date(),
  open: false,
  open2: false,
  classVal: "",
  subjectVal: "",
};

export const reportSearchSlice = createSlice({
  name: "reportSearch",
  initialState: searchOptions,
  reducers: {
    setDate(state, action) {
      state.date = action.payload;
    },
    setDate2(state, action) {
      return { ...state, date2: action.payload };
    },
    setOpen(state, action) {
      return { ...state, open: action.payload };
    },
    setOpen2(state, action) {
      return { ...state, open2: action.payload };
    },
    setClassVal(state, action) {
      return { ...state, classVal: action.payload };
    },
    setSubjectVal(state, action) {
      return { ...state, subjectVal: action.payload };
    },
  },
});

export const {
  setDate,
  setDate2,
  setOpen,
  setOpen2,
  setClassVal,
  setSubjectVal,
} = reportSearchSlice.actions;

export default reportSearchSlice.reducer;
