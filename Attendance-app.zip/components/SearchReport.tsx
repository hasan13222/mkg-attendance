
const SearchReport = () => {
    return (
        <>
            
        </>
    );
};

export default SearchReport;